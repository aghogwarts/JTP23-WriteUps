![image](https://github.com/itstanayhere/phase2_2/assets/147296398/2c7d8bbc-3151-4e99-b2d3-d7d289e8f69f)

We simply download the table given and solve it. The answer comes out to be

![image](https://github.com/itstanayhere/phase2_2/assets/147296398/acbe7dd8-9456-4d42-bd0d-4b1c01c05eb5)

CRYPTOISFUN.

This text is our flag.
