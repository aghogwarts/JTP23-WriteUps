We download the file:
![image](https://github.com/itstanayhere/phase2_2/assets/147296398/4403cc8f-e9a5-4ba4-aa4a-539f3b43c691)
Now we have to decompile it. Since Ghidra could not do it, I used an online decompiler.

Following was the code:
![image](https://github.com/itstanayhere/phase2_2/assets/147296398/8d052f96-fc69-44b2-898a-f24a5d1f6d4a)
All we have to do is comapre the characters to their relevant positions and we will get our flag.
![image](https://github.com/itstanayhere/phase2_2/assets/147296398/8824db7c-6a9a-4d66-85a2-f27819dd9e7d)
