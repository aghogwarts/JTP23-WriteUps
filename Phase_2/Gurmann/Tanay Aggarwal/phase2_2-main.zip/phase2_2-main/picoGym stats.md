![image](https://github.com/itstanayhere/phase2_2/assets/147296398/57ec8710-8d4d-4362-b642-0179bb1bca13)
(stonks was left unsolved as the flag extracted was not being accepted. hence the 4 challenges in binary exploitation)
