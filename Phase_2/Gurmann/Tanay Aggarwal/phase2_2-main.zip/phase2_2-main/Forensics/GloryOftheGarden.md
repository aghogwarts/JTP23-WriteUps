Glory of the Garden

![image](https://github.com/itstanayhere/phase2_2/assets/147296398/7e4b1cbf-fadf-4512-ace6-2202faa8dc40)

We download the file and open its hex

![image](https://github.com/itstanayhere/phase2_2/assets/147296398/4062c60f-b048-4204-ae09-575045537ef4)

Scrolling towards the end, we find a flag.
