We download the file, as per the instructions given, search for the “known prefix”, in this case, “picoCTF”.

![image](https://github.com/itstanayhere/phase2_2/assets/147296398/c141d96c-a1ad-4dcd-9ed3-4751d297255c)

This is our flag.
